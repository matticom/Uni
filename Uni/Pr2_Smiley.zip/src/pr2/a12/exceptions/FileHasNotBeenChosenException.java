package pr2.a12.exceptions;

public class FileHasNotBeenChosenException extends Exception{

	public FileHasNotBeenChosenException() {
		
	}
	
	public FileHasNotBeenChosenException(String message) {
		super(message);
	}

}
