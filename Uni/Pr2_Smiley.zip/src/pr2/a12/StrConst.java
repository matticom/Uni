package pr2.a12;

public class StrConst {
	public static final String MB_FILE = "MB_FILE";
	public static final String MB_SAVE = "MB_SAVE";
	public static final String MB_LOAD = "MB_LOAD";
	public static final String MB_EXIT = "MB_EXIT";
	public static final String MB_SMILEY = "MB_SMILEY";
	public static final String MB_SMILE = "MB_SMILE";
	public static final String MB_HEAD = "MB_HEAD";
	public static final String MB_H_INC = "MB_H_INC";
	public static final String MB_H_DEC = "MB_H_DEC";
	public static final String MB_EYES = "MB_EYES";
	public static final String MB_E_ROT_LEFT = "MB_E_ROT_LEFT";
	public static final String MB_E_ROT_RIGHT = "MB_E_ROT_RIGHT";
	public static final String MB_PLEASED = "MB_PLEASED";
	public static final String MB_SAD = "MB_SAD";
	public static final String MB_RESET = "MB_RESET";
	public static final String MB_LANG = "MB_LANG";
	public static final String MB_EN = "MB_EN";
	public static final String MB_DE = "MB_DE";
	public static final String MB_ES = "MB_ES";
	
	public static final String BTN_STFY = "BTN_STFY";
	public static final String BTN_SAD = "BTN_SAD";
	public static final String TF_EYE_RADIUS = "TF_EYE_RADIUS";
	public static final String TF_HEAD_RADIUS = "TF_HEAD_RADIUS";
	public static final String SPIN_EYE_ANGLE = "SPIN_EYE_ANGLE";
	public static final String CB_SMILE = "CB_SMILE";
	public static final String LBL_HEAD_RADIUS = "LBL_HEAD_RADIUS";
	public static final String LBL_EYE_RADIUS = "LBL_EYE_RADIUS";
	public static final String LBL_EYE_ANGLE = "LBL_EYE_ANGLE";
	public static final String LBL_MOOD = "LBL_MOOD";
	
	public static final String BTN_UP = "BTN_UP";
	public static final String BTN_DOWN = "BTN_DOWN";
	public static final String BTN_LEFT = "BTN_LEFT";
	public static final String BTN_RIGHT = "BTN_RIGHT";
}
